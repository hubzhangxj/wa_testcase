build_qperf() {

    arch=`uname -i`
    #set -e
    if [ $arch = "aarch64" ]
    then
       para=aarch64-unknown-linux-gnu
    fi
    ./configure  --build=$para
    sleep 2 
    make && make install
}

build_qperf









